package com.frame.word;

import com.aspose.words.Document;
import com.aspose.words.DocumentBuilder;
import com.aspose.words.IReplacingCallback;
import com.aspose.words.Node;
import com.aspose.words.RelativeHorizontalPosition;
import com.aspose.words.RelativeVerticalPosition;
import com.aspose.words.ReplaceAction;
import com.aspose.words.ReplacingArgs;
import com.aspose.words.WrapType;

/**
 * @Description :
 * @Author : wangjun
 * @Date: 2021-06-24 16:41
 */
public class ReplaceAndInsertImage implements IReplacingCallback {
    public WordReplaceParam wordReplaceParam;
    public ReplaceAndInsertImage(WordReplaceParam wordReplaceParam){
        this.wordReplaceParam = wordReplaceParam;
    }

    @Override
    public int replacing(ReplacingArgs e) throws Exception {
        //获取当前节点
        Node node = e.getMatchNode();
        //获取当前文档
        Document document =  (Document) node.getDocument();
        DocumentBuilder builder = new DocumentBuilder(document);
        //将光标移动到指定节点
        builder.moveTo(node);
        //插入图片 默认宽高
//        builder.insertImage(wordReplaceParam.getReplaceImageUrl());
        builder.insertImage(wordReplaceParam.getReplaceImageUrl(), RelativeHorizontalPosition.MARGIN, 0,
                RelativeVerticalPosition.MARGIN, 0, wordReplaceParam.getImageWidth(),wordReplaceParam.getImageHeight(), WrapType.INLINE);
//        builder.getParagraphFormat().setLineSpacing(0);
        return ReplaceAction.REPLACE;
    }
}