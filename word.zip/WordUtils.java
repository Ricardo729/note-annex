package com.frame.word;

import com.aspose.words.Document;
import com.aspose.words.License;
import com.aspose.words.Range;
import com.aspose.words.SaveFormat;
import com.frame.utils.HttpRequest;
import org.apache.log4j.Logger;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

/**
 * @Description : word处理工具类
 * @Author : wangjun
 * @Date: 2021-06-24 14:51
 */
public class WordUtils {
    private static Logger log = Logger.getLogger(HttpRequest.class);

    private static boolean getLicense() {
        boolean result = false;
        try {
            // license.xml应放在..\WebRoot\WEB-INF\classes路径下
            InputStream is = WordUtils.class.getClassLoader().getResourceAsStream("asposeLicense.xml");
            License aposeLic = new License();
            aposeLic.setLicense(is);
            result = true;
        } catch (Exception e) {
            log.error(String.format("[getLicense] 获取aspose license失败，原因是：%s", e.getMessage()));
        }
        return result;
    }

    /**
     * doc转pdf
     *
     * @param docPath 转换原文件doc路径
     * @param pdfPath 新pdf路径
     */
    public static boolean doc2pdf(String docPath, String pdfPath) {
        // 验证License 若不验证则转化出的pdf文档会有水印产生
        if (!getLicense()) {
            return false;
        }
        FileOutputStream os = null;
        try {
            // 新建一个空白pdf文档
            File file = new File(pdfPath);
            os = new FileOutputStream(file);
            // Address是将要被转化的word文档
            Document doc = new Document(docPath);
            // 全面支持DOC, DOCX, OOXML, RTF HTML, OpenDocument, PDF, EPUB, XPS, SWF 相互转换
            doc.save(os, SaveFormat.PDF);
        } catch (Exception e) {
            log.error(String.format("[doc2pdf] word转换为pdf失败，原因是：%s", e.getMessage()));
            return false;
        } finally {
            if (os != null) {
                try {
                    os.close();
                } catch (IOException e) {
                    log.error(String.format("[doc2pdf] 输出流关闭失败，原因是：%s", e.getMessage()));
                }
            }
        }
        return true;
    }

    /**
     * aspose word 替换文字/图片。
     *
     * @param url     原文件路径
     * @param saveurl 保存路径
     * @param wordReplaceParamList wordReplaceParam列表 详见WordReplaceParam类
     * @return 是否替换成功
     */
    public static boolean replace(String url, String saveurl, List<WordReplaceParam> wordReplaceParamList ) {
        if (!getLicense()) {
            return false;
        }
        File file = new File(url);
        if (!file.exists()) {
            return false;
        }
        try {
            Document doc = new Document(url);
            Range range = doc.getRange();
            for (WordReplaceParam wordReplaceParam : wordReplaceParamList) {
                String key = wordReplaceParam.getOldLabel();
                if (wordReplaceParam.getType() == WordReplaceParam.REPLACE_TYPE_IMAGE) {
                    key = convertToRegex(key);
                    range.replace(Pattern.compile(key), new ReplaceAndInsertImage(wordReplaceParam), false);
                } else {
                    range.replace(key, wordReplaceParam.getReplaceContent(), true, false);
                }
            }
            doc.save(saveurl);
        } catch (Exception e) {
            log.error("[replace] 替换word中标签失败，原因是：" + e.getMessage());
            return false;
        }
        return true;
    }

    private static String convertToRegex(String key) {
        key = key.replace("\\", "\\\\");
        key = key.replace("$", "\\$");
        key = key.replace("[", "\\[");
        key = key.replace("]", "\\]");
        key = key.replace("(", "\\(");
        key = key.replace(")", "\\)");
        key = key.replace("|", "\\|");
        key = key.replace("+", "\\+");
        key = key.replace("?", "\\?");
        key = key.replace("*", "\\*");
        key = key.replace("{", "\\{");
        key = key.replace("}", "\\}");
        return key;
    }


    public static void main(String[] args) {
        doc2pdf("D:/ylys/物流/在线文档编辑/在线文档编辑/预研/test/测试表格新输出.docx","D:/ylys/物流/在线文档编辑/在线文档编辑/预研/test/测试表格新输出1.pdf");
        // 替换模板中的${**}
        List<WordReplaceParam> wordReplaceParamList = new ArrayList<>();
        wordReplaceParamList.add(new WordReplaceParam("${partA}", "陕钢集团韩城钢铁有限责任公司", WordReplaceParam.REPLACE_TYPE_TEXT));
        wordReplaceParamList.add(new WordReplaceParam("${partB}", "江苏新科达环保科技有限公司", WordReplaceParam.REPLACE_TYPE_TEXT));
        wordReplaceParamList.add(new WordReplaceParam("${partA_address}", "太华西路", WordReplaceParam.REPLACE_TYPE_TEXT));
        wordReplaceParamList.add(new WordReplaceParam("${partB_address}", "阜城工业园D区58号", WordReplaceParam.REPLACE_TYPE_TEXT));
        wordReplaceParamList.add(new WordReplaceParam("${partA_legal_person}", "阮锐", WordReplaceParam.REPLACE_TYPE_TEXT));
        wordReplaceParamList.add(new WordReplaceParam("${partB_legal_person}", "张育东", WordReplaceParam.REPLACE_TYPE_TEXT));
        wordReplaceParamList.add(new WordReplaceParam("${partA_agent}","D:/测试文件夹/测试1.png", WordReplaceParam.REPLACE_TYPE_IMAGE, 80, 60));
        wordReplaceParamList.add(new WordReplaceParam("${partB_agent}","D:/测试文件夹/测试3.png", WordReplaceParam.REPLACE_TYPE_IMAGE, 80, 60));
        WordUtils.replace("D:/ylys/物流/在线文档编辑/在线文档编辑/预研/test/测试表格模板.docx", "D:/ylys/物流/在线文档编辑/在线文档编辑/预研/test/测试表格新输出.docx", wordReplaceParamList);
    }
}