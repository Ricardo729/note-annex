package com.frame.word;

/**
 * @Description :
 * @Author : word
 * @Date: 2021-06-24 18:00
 */
public class WordReplaceParam {
    /**
     * 替换文本构造函数
     *
     * @param oldLabel 待替换的旧标签
     * @param replaceContent 替换的内容
     * @param type 替换的类型
     */
    public WordReplaceParam(String oldLabel, String replaceContent, int type) {
        this.oldLabel = oldLabel;
        this.replaceContent = replaceContent;
        this.type = type;
    }

    /**
     * 替换图片的构造函数
     *
     * @param oldLabel 待替换的旧标签
     * @param replaceImageUrl 待插入图片的路径
     * @param type 替换的类型
     * @param imageWidth 图片宽度
     * @param imageHeight 图片高度
     */
    public WordReplaceParam(String oldLabel, String replaceImageUrl, int type, int imageWidth, int imageHeight) {
        this.oldLabel = oldLabel;
        this.replaceImageUrl = replaceImageUrl;
        this.type = type;
        this.imageWidth = imageWidth;
        this.imageHeight = imageHeight;
    }


    /**
     * 替换类型：文本
     */
    public static final int REPLACE_TYPE_TEXT = 0;
    /**
     * 替换类型：图片
     */
    public static final int REPLACE_TYPE_IMAGE = 1;

    /**
     * 需要替换的标签
     */
    private String oldLabel;

    /**
     * 文本替换内容
     */
    private String replaceContent;

    /**
     * 待替换图片url
     */
    private String replaceImageUrl;

    /**
     * 替换类型
     */
    private int type;

    /**
     * 图片宽度
     */
    private int imageWidth;

    /**
     * 图片高度
     */
    private int imageHeight;

    public String getOldLabel() {
        return oldLabel;
    }

    public void setOldLabel(String oldLabel) {
        this.oldLabel = oldLabel;
    }

    public String getReplaceContent() {
        return replaceContent;
    }

    public void setReplaceContent(String replaceContent) {
        this.replaceContent = replaceContent;
    }

    public String getReplaceImageUrl() {
        return replaceImageUrl;
    }

    public void setReplaceImageUrl(String replaceImageUrl) {
        this.replaceImageUrl = replaceImageUrl;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public int getImageWidth() {
        return imageWidth;
    }

    public void setImageWidth(int imageWidth) {
        this.imageWidth = imageWidth;
    }

    public int getImageHeight() {
        return imageHeight;
    }

    public void setImageHeight(int imageHeight) {
        this.imageHeight = imageHeight;
    }
}